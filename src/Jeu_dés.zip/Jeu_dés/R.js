import img from './dés/img.jpg';
import imgvide from './dés/vide.png';
import img1 from './dés/f1.png';
import img2 from './dés/f2.png';
import img3 from './dés/F3.png';
import img4 from './dés/F4.png';
import img5 from './dés/F5.png';
import img6 from './dés/F6.jpg';

let i={
        img:img,
        imgvide: imgvide,
        img1: img1,
        img2: img2,
        img3: img3,
        img4: img4,
        img5: img5,
        img6: img6,
}
export default i ;